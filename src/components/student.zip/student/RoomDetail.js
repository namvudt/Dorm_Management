import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const RoomDetail = () => {
  const navigate = useNavigate();
  const [roomInfo, setRoomInfo] = useState(null);

  useEffect(() => {
    const storedRoom = localStorage.getItem('roomDetail');

    if (storedRoom) {
      setRoomInfo(JSON.parse(storedRoom));
    } else {
      alert('Không tìm thấy thông tin phòng! Vui lòng đăng ký lại.');
      navigate('/student/dashboard');
    }
  }, [navigate]);

  const handleBackToDashboard = () => {
    navigate('/student/dashboard');
  };

  if (!roomInfo) {
    return <p style={styles.loading}>Đang tải thông tin phòng...</p>;
  }

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Thông tin phòng {roomInfo.roomId}</h2>

      <div style={styles.infoContainer}>
        <div style={styles.infoRow}>
          <span style={styles.label}>Mã phòng:</span>
          <span style={styles.value}>{roomInfo.roomId}</span>
        </div>

        <div style={styles.infoRow}>
          <span style={styles.label}>Sức chứa tối đa:</span>
          <span style={styles.value}>{roomInfo.capacity} sinh viên</span>
        </div>

        <div style={styles.infoRow}>
          <span style={styles.label}>Số sinh viên hiện tại:</span>
          <span style={styles.value}>{roomInfo.currentStudents} sinh viên</span>
        </div>

        <div style={styles.infoRow}>
          <span style={styles.label}>Trạng thái thiết bị:</span>
          <span style={styles.value}>{roomInfo.deviceStatus}</span>
        </div>

        <div style={styles.infoRow}>
          <span style={styles.label}>Diện tích phòng:</span>
          <span style={styles.value}>{roomInfo.area}</span>
        </div>

        <div style={styles.infoRow}>
          <span style={styles.label}>Giá phòng:</span>
          <span style={styles.value}>{roomInfo.price}</span>
        </div>
      </div>

      <div style={styles.buttonContainer}>
        <button onClick={handleBackToDashboard} style={styles.backButton}>
          🔙 Quay lại Dashboard
        </button>
      </div>
    </div>
  );
};

const styles = {
  container: {
    padding: '20px',
    maxWidth: '600px',
    margin: '0 auto',
    backgroundColor: '#f9f9f9',
    borderRadius: '8px',
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
  },
  title: {
    textAlign: 'center',
    marginBottom: '20px',
    fontSize: '24px',
    color: '#333',
  },
  infoContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
  },
  infoRow: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '12px',
    backgroundColor: '#fff',
    borderRadius: '6px',
    border: '1px solid #ddd',
  },
  label: {
    fontWeight: 'bold',
    color: '#555',
  },
  value: {
    color: '#333',
  },
  buttonContainer: {
    marginTop: '20px',
    display: 'flex',
    justifyContent: 'center',
  },
  backButton: {
    padding: '10px 20px',
    backgroundColor: '#9E9E9E',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
  },
  loading: {
    textAlign: 'center',
    padding: '20px',
    color: '#777',
  },
};

export default RoomDetail;
