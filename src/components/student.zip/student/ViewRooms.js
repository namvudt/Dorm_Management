// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';

// function ViewRooms() {
//   const navigate = useNavigate();
//   const [rooms, setRooms] = useState([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     axios
//       .get('/api/rooms')
//       .then((response) => {
//         setRooms(response.data);
//         setLoading(false);
//       })
//       .catch((error) => {
//         console.error(error);
//         alert('Không thể tải danh sách phòng');
//         setLoading(false);
//       });
//   }, []);

//   return (
//     <div style={styles.container}>
//       <button onClick={() => navigate('/student/dashboard')} style={styles.backButton}>
//         ← Quay lại Dashboard
//       </button>

//       <h2 style={styles.title}>Danh Sách Phòng</h2>

//       {loading ? (
//         <p>Đang tải dữ liệu...</p>
//       ) : rooms.length === 0 ? (
//         <p>Không có phòng nào.</p>
//       ) : (
//         <table style={styles.table}>
//           <thead>
//             <tr>
//               <th style={styles.th}>STT</th>
//               <th style={styles.th}>Tên Phòng</th>
//             </tr>
//           </thead>
//           <tbody>
//             {rooms.map((room, index) => (
//               <tr key={room.id || room.name}>
//                 <td style={styles.td}>{index + 1}</td>
//                 <td style={styles.td}>{room.name}</td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       )}
//     </div>
//   );
// }

// const styles = {
//   container: {
//     padding: '20px',
//     maxWidth: '800px',
//     margin: '0 auto',
//     textAlign: 'center',
//   },
//   title: {
//     fontSize: '24px',
//     marginBottom: '20px',
//   },
//   table: {
//     width: '100%',
//     borderCollapse: 'collapse',
//     marginTop: '20px',
//   },
//   th: {
//     border: '1px solid #ddd',
//     padding: '12px',
//     backgroundColor: '#f2f2f2',
//     fontWeight: 'bold',
//   },
//   td: {
//     border: '1px solid #ddd',
//     padding: '12px',
//   },
//   backButton: {
//     marginBottom: '20px',
//     backgroundColor: '#2196F3',
//     color: 'white',
//     padding: '8px 16px',
//     border: 'none',
//     cursor: 'pointer',
//     borderRadius: '4px',
//   },
// };

// export default ViewRooms;
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function ViewRooms() {
  const navigate = useNavigate();
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Giả lập delay 1 giây rồi gán dữ liệu mẫu
    const timer = setTimeout(() => {
      const sampleRooms = [
        { id: 1, name: 'Phòng 101' },
        { id: 2, name: 'Phòng 102' },
        { id: 3, name: 'Phòng 103' },
      ];

      setRooms(sampleRooms);
      setLoading(false);
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  const handleRegister = (room) => {
    // Tạm thời chỉ alert, bạn có thể thay bằng API call sau này
    alert(`Đăng ký thành công phòng: ${room.name}`);
  };

  return (
    <div style={styles.container}>
      <button onClick={() => navigate('/student/dashboard')} style={styles.backButton}>
        ← Quay lại Dashboard
      </button>

      <h2 style={styles.title}>Danh Sách Phòng</h2>

      {loading ? (
        <p>Đang tải dữ liệu...</p>
      ) : rooms.length === 0 ? (
        <p>Không có phòng nào.</p>
      ) : (
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>STT</th>
              <th style={styles.th}>Tên Phòng</th>
              <th style={styles.th}>Hành Động</th>
            </tr>
          </thead>
          <tbody>
            {rooms.map((room, index) => (
              <tr key={room.id || room.name}>
                <td style={styles.td}>{index + 1}</td>
                <td style={styles.td}>{room.name}</td>
                <td style={styles.td}>
                  <button
                    onClick={() => handleRegister(room)}
                    style={styles.registerButton}
                  >
                    Đăng Ký
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '800px',
    margin: '0 auto',
    textAlign: 'center',
  },
  title: {
    fontSize: '24px',
    marginBottom: '20px',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '20px',
  },
  th: {
    border: '1px solid #ddd',
    padding: '12px',
    backgroundColor: '#f2f2f2',
    fontWeight: 'bold',
  },
  td: {
    border: '1px solid #ddd',
    padding: '12px',
  },
  backButton: {
    marginBottom: '20px',
    backgroundColor: '#2196F3',
    color: 'white',
    padding: '8px 16px',
    border: 'none',
    cursor: 'pointer',
    borderRadius: '4px',
  },
  registerButton: {
    backgroundColor: '#4CAF50',
    color: 'white',
    padding: '8px 12px',
    border: 'none',
    cursor: 'pointer',
    borderRadius: '4px',
  },
};

export default ViewRooms;
