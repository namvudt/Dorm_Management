import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function RegisterRoom() {
  const navigate = useNavigate();
  const [roomName, setRoomName] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!roomName) {
      alert('Vui lòng nhập tên phòng');
      return;
    }

    try {
      setLoading(true);

      // ➡️ Giả lập đăng ký phòng thành công
      setTimeout(() => {
        // ➡️ Dữ liệu chi tiết phòng
        const roomDetail = {
          roomId: roomName,
          capacity: 4,
          currentStudents: 2,
          deviceStatus: 'Tốt',
          area: '25 m²',
          price: '1,500,000 VND/tháng',
        };

        // ➡️ Lưu thông tin vào localStorage để RoomDetail lấy ra
        localStorage.setItem('roomDetail', JSON.stringify(roomDetail));

        alert('Đăng ký phòng thành công!');
        navigate('/student/room-detail'); // ➡️ Điều hướng sang RoomDetail
      }, 1000);
    } catch (error) {
      console.error(error);
      alert('Đã xảy ra lỗi!');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <button onClick={() => navigate('/student/dashboard')} style={styles.backButton}>
        ← Quay lại Dashboard
      </button>

      <h2 style={styles.title}>Đăng Ký Thuê Phòng</h2>

      <form onSubmit={handleSubmit} style={styles.form}>
        <input
          type="text"
          value={roomName}
          onChange={(e) => setRoomName(e.target.value)}
          placeholder="Tên phòng muốn thuê"
          style={styles.input}
        />

        <button type="submit" style={styles.submitButton} disabled={loading}>
          {loading ? 'Đang đăng ký...' : 'Đăng Ký'}
        </button>
      </form>
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '500px',
    margin: '0 auto',
    textAlign: 'center',
  },
  title: {
    fontSize: '24px',
    marginBottom: '20px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
  },
  input: {
    padding: '10px',
    fontSize: '16px',
    borderRadius: '4px',
    border: '1px solid #ccc',
  },
  submitButton: {
    padding: '10px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    cursor: 'pointer',
    fontSize: '16px',
    borderRadius: '4px',
  },
  backButton: {
    marginBottom: '20px',
    backgroundColor: '#2196F3',
    color: 'white',
    padding: '8px 16px',
    border: 'none',
    cursor: 'pointer',
    borderRadius: '4px',
  },
};

export default RegisterRoom;
