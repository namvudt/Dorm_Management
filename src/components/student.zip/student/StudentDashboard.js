import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ChangePasswordPopup from '../ChangePasswordPopup';

const StudentDashboard = ({ onLogout }) => {
  const navigate = useNavigate();
  const [showChangePasswordPopup, setShowChangePasswordPopup] = useState(false);

  const handleLogoutClick = () => {
    if (onLogout) onLogout();
    navigate('/login');
  };

  const handleChangePasswordClick = () => {
    setShowChangePasswordPopup(true);
  };

  const handleViewRoomsClick = () => {
    navigate('/student/view-rooms');
  };

  const handleViewProfileClick = () => {
    navigate('/student/my-profile');
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Student Dashboard</h1>

      <div style={styles.buttonContainer}>
        <button
          onClick={handleViewRoomsClick}
          style={styles.actionButton}
        >
          📋 Xem Danh sách Phòng
        </button>

        <button
          onClick={handleViewProfileClick}
          style={styles.actionButton}
        >
          👤 Xem Thông Tin Cá Nhân
        </button>
      </div>

      {/* Footer Buttons */}
      <div style={styles.footerContainer}>
        <button
          onClick={handleChangePasswordClick}
          style={styles.footerButton}
        >
          🔒 Đổi Mật Khẩu
        </button>

        <button
          onClick={handleLogoutClick}
          style={styles.footerButtonLogout}
        >
          🚪 Đăng Xuất
        </button>
      </div>

      {/* Popup Đổi mật khẩu */}
      {showChangePasswordPopup && (
        <ChangePasswordPopup onClose={() => setShowChangePasswordPopup(false)} />
      )}
    </div>
  );
};

const styles = {
  container: {
    padding: '20px',
    minHeight: '100vh',
    backgroundColor: '#f0f2f5',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: '36px',
    color: '#333',
    marginBottom: '40px',
  },
  buttonContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
    width: '100%',
    maxWidth: '400px',
    marginBottom: '40px',
  },
  actionButton: {
    padding: '14px 20px',
    fontSize: '18px',
    backgroundColor: '#4CAF50',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'background-color 0.3s, transform 0.2s',
  },
  footerContainer: {
    display: 'flex',
    justifyContent: 'center',
    gap: '20px',
  },
  footerButton: {
    padding: '12px 20px',
    fontSize: '16px',
    backgroundColor: '#FF9800',
    color: '#fff',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
  },
  footerButtonLogout: {
    padding: '12px 20px',
    fontSize: '16px',
    backgroundColor: '#f44336',
    color: '#fff',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'background-color 0.3s',
  },
};

export default StudentDashboard;
